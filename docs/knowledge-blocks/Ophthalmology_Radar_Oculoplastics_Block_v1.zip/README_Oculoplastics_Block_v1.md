# Ophthalmology Radar — Oculoplastics Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- oculoplastics_01_pathologies.csv
- oculoplastics_02_medications.csv
- oculoplastics_03_guidelines.csv
- oculoplastics_04_classifications.csv
- oculoplastics_05_educational_cases.csv
- oculoplastics_06_devices.csv
- oculoplastics_07_protocols.csv
- oculoplastics_supabase_import_v1.sql
- oculoplastics_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
