# Ophthalmology Radar — Ophthalmic Emergencies Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- emergencies_01_pathologies.csv
- emergencies_02_medications.csv
- emergencies_03_guidelines.csv
- emergencies_04_classifications.csv
- emergencies_05_educational_cases.csv
- emergencies_06_devices.csv
- emergencies_07_protocols.csv
- emergencies_supabase_import_v1.sql
- emergencies_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
