# Ophthalmology Radar — Ocular Oncology and Orbit Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- ocular_oncology_orbit_01_pathologies.csv
- ocular_oncology_orbit_02_medications.csv
- ocular_oncology_orbit_03_guidelines.csv
- ocular_oncology_orbit_04_classifications.csv
- ocular_oncology_orbit_05_educational_cases.csv
- ocular_oncology_orbit_06_devices.csv
- ocular_oncology_orbit_07_protocols.csv
- ocular_oncology_orbit_supabase_import_v1.sql
- ocular_oncology_orbit_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
