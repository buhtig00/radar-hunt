# Ophthalmology Radar — Refractive Surgery Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- refractive_01_pathologies.csv
- refractive_02_medications.csv
- refractive_03_guidelines.csv
- refractive_04_classifications.csv
- refractive_05_educational_cases.csv
- refractive_06_devices.csv
- refractive_07_protocols.csv
- refractive_supabase_import_v1.sql
- refractive_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
