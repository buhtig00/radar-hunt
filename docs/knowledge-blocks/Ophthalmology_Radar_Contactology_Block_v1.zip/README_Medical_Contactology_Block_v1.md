# Ophthalmology Radar — Medical Contactology Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- contactology_01_pathologies.csv
- contactology_02_medications.csv
- contactology_03_guidelines.csv
- contactology_04_classifications.csv
- contactology_05_educational_cases.csv
- contactology_06_devices.csv
- contactology_07_protocols.csv
- contactology_supabase_import_v1.sql
- contactology_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
