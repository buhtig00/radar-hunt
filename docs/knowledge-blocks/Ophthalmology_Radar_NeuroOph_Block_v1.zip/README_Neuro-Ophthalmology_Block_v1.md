# Ophthalmology Radar — Neuro-Ophthalmology Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- neuro_ophthalmology_01_pathologies.csv
- neuro_ophthalmology_02_medications.csv
- neuro_ophthalmology_03_guidelines.csv
- neuro_ophthalmology_04_classifications.csv
- neuro_ophthalmology_05_educational_cases.csv
- neuro_ophthalmology_06_devices.csv
- neuro_ophthalmology_07_protocols.csv
- neuro_ophthalmology_supabase_import_v1.sql
- neuro_ophthalmology_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
