# Ophthalmology Radar — Low Vision and Visual Rehabilitation Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- low_vision_01_pathologies.csv
- low_vision_02_medications.csv
- low_vision_03_guidelines.csv
- low_vision_04_classifications.csv
- low_vision_05_educational_cases.csv
- low_vision_06_devices.csv
- low_vision_07_protocols.csv
- low_vision_supabase_import_v1.sql
- low_vision_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
