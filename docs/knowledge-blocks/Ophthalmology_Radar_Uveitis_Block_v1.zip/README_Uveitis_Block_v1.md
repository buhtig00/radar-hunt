# Ophthalmology Radar — Uveitis Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- uveitis_01_pathologies.csv
- uveitis_02_medications.csv
- uveitis_03_guidelines.csv
- uveitis_04_classifications.csv
- uveitis_05_educational_cases.csv
- uveitis_06_devices.csv
- uveitis_07_protocols.csv
- uveitis_supabase_import_v1.sql
- uveitis_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
