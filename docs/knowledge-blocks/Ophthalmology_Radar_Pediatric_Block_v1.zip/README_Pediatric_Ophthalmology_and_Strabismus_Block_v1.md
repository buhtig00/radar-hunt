# Ophthalmology Radar — Pediatric Ophthalmology and Strabismus Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- pediatric_strabismus_01_pathologies.csv
- pediatric_strabismus_02_medications.csv
- pediatric_strabismus_03_guidelines.csv
- pediatric_strabismus_04_classifications.csv
- pediatric_strabismus_05_educational_cases.csv
- pediatric_strabismus_06_devices.csv
- pediatric_strabismus_07_protocols.csv
- pediatric_strabismus_supabase_import_v1.sql
- pediatric_strabismus_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
