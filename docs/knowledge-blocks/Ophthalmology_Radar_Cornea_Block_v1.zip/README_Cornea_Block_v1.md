# Ophthalmology Radar — Cornea Block v1

This package contains a structured Cornea knowledge block for Supabase.

## Contents
- cornea_01_pathologies.csv: 23 pathology monographs
- cornea_02_medications.csv: 15 medications/classes
- cornea_03_guidelines.csv: 8 guidelines/consensus/regulatory sources
- cornea_04_classifications.csv: 8 classifications/staging systems
- cornea_05_educational_cases.csv: 10 synthetic educational cases, not real patients
- cornea_06_devices.csv: 12 devices/technology entries
- cornea_07_protocols.csv: 4 educational protocols
- cornea_supabase_import_v1.sql: SQL import script
- cornea_rag_seed_knowledge_sources.jsonl: RAG seed file

## Import
1. Run the master clinical KB schema first.
2. Paste and execute cornea_supabase_import_v1.sql in Supabase SQL Editor.
3. Keep all rows as pending_review and inactive until medical/KOL validation.

## Safety
Clinical cases are synthetic educational templates and are labelled as not real patients.
Do not activate content for clinical production until editorial and KOL review are complete.
