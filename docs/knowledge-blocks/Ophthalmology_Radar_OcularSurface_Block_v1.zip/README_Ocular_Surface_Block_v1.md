# Ophthalmology Radar — Ocular Surface Block v1

Generated: 2026-05-31

This package contains structured ocular surface knowledge base files for Supabase import.

## Files
- `ocular_surface_01_pathologies.csv` — 21 pathology monographs
- `ocular_surface_02_medications.csv` — 15 medications/classes
- `ocular_surface_03_guidelines.csv` — 8 guideline/source records
- `ocular_surface_04_classifications.csv` — 8 classifications
- `ocular_surface_04b_classification_items.csv` — 31 classification items
- `ocular_surface_05_educational_cases.csv` — 10 synthetic educational cases
- `ocular_surface_06_devices.csv` — 12 diagnostic/therapeutic devices
- `ocular_surface_07_protocols.csv` — 4 educational protocols
- `ocular_surface_supabase_import_v1.sql` — SQL insert script
- `ocular_surface_rag_seed_knowledge_sources.jsonl` — RAG/embedding seed

## Import order
1. Run the main clinical KB schema first.
2. Execute `ocular_surface_supabase_import_v1.sql` in Supabase SQL Editor.
3. Review all records editorially/KOL.
4. Only then set `status='approved'` and `is_active=true`.

## Important
Clinical cases are synthetic educational cases, not real patients.
Medication entries are educational and not prescribing instructions. Verify EMA/CIMA/local labels before clinical or commercial use.
