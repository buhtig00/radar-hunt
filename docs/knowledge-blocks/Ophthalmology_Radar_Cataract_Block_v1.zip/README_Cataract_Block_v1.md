# Ophthalmology Radar — Cataract Block v1

This package contains CSV, SQL and JSONL files to seed the Ophthalmology Radar clinical knowledge base.

Files:
- cataract_01_pathologies.csv
- cataract_02_medications.csv
- cataract_03_guidelines.csv
- cataract_04_classifications.csv
- cataract_05_educational_cases.csv
- cataract_06_devices.csv
- cataract_07_protocols.csv
- cataract_supabase_import_v1.sql
- cataract_rag_seed_knowledge_sources.jsonl

All records are intentionally set as pending_review and inactive.
Clinical/editorial/KOL review is required before activation.

Cases are synthetic educational cases and not real patient records.
